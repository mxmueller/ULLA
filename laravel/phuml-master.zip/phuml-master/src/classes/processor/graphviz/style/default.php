<?php

class plGraphvizProcessorDefaultStyle extends plGraphvizProcessorStyle
{
}

?>
